# Soporte de la Actividad 3.4

La pila de observabilidad se entrega prácticamente preparada. El objetivo de
la actividad no es administrar Elastic Stack, sino interpretar los datos que
genera el despliegue.

## Estructura

```text
actividad-3.4-soporte/
├── compose.observabilidad.yaml
├── fluent-bit.conf
├── parsers.conf
├── genera-trafico.sh
├── prepara-host.sh
├── kibana-init.sh
└── LEEME.md
```

En el repositorio deben quedar:

```text
practicas/
├── compose/
│   └── compose.observabilidad.yaml
└── observabilidad/
    ├── fluent-bit/
    │   ├── fluent-bit.conf
    │   └── parsers.conf
    ├── genera-trafico.sh
    ├── prepara-host.sh
    └── kibana-init.sh
```

Haz ejecutables los scripts:

```bash
chmod +x practicas/observabilidad/*.sh
```

## Qué se automatiza

`prepara-host.sh`:

- configura `vm.max_map_count`;
- crea y activa 2 GiB de swap si todavía no existe;
- muestra el estado final de memoria.

`kibana-init.sh` se ejecuta automáticamente mediante Compose y crea:

```text
Data view: Escaparate
Patrón:    escaparate-*
Tiempo:    @timestamp
```

También lo establece como data view predeterminado.

No hace falta crear manualmente el data view en Kibana.

## Publicación inicial de Kibana

El fichero inicial deja:

```text
24224 → 127.0.0.1
9200  → 127.0.0.1
5601  → publicado temporalmente
```

La actividad utiliza esta publicación para demostrar el problema y después
hace cambiar:

```yaml
- "5601:5601"
```

por:

```yaml
- "127.0.0.1:5601:5601"
```

El estado final será:

```text
24224 → 127.0.0.1
9200  → 127.0.0.1
5601  → 127.0.0.1
```

Kibana se consultará entonces mediante un túnel SSH y
`http://localhost:5601`.

No abras nunca `9200` ni `24224` en el Security Group.
